#include <stdio.h>
#include "verwaltung.h"

int main()
{

  Stdnt st1 = {"Pascal", ENG, 45};
  Stdnt st2 = {"Olli", ENG, 60};
  Stdnt st3 = {"Philip", ENG, 10};
  Stdnt st4 = {"PascalS", MATHE, 30};

  printIfmStudents();
  addStudentMainList(&st1);
  addStudentMainList(&st2);
  addStudentMainList(&st3);
  addStudentMainList(&st4);
  printMainList();
  printIfmStudents();
  removeStudent(&st1, 1);

  printMainList();
  printIfmStudents();
}